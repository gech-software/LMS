﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace liabrary_management_sysytem_using_c_
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
        }

        private void txtusername_MouseClick(object sender, MouseEventArgs e)
        {
            if (txtusername.Text == "Username") ;
            txtusername.Clear();
        }

        private void txtpassword_MouseClick(object sender, MouseEventArgs e)
        {
            if (txtpassword.Text == "Password") ;
            txtpassword.Clear();
            txtpassword.PasswordChar = '*';
        }

        private void insta_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("www.instagram.com");
        }

        private void facebook_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("www.facebook.com");
        }

        private void btnlogin_Click(object sender, EventArgs e)
        {


            SqlConnection conn = new SqlConnection();
            SqlCommand com = new SqlCommand();
            conn.ConnectionString="data source =   ;database=   ; intgrated sercuity=True";
            com.CommandText = "select * from  where username ='"+txtusername.Text+"','"+txtpassword.Text+"')";
            SqlDataAdapter da = new SqlDataAdapter();
            DataSet ds = new DataSet();
            da.Fill(ds);

            if (ds.Tables[0].Rows.Count != 0)
            {
                this.Hide();
                menu men= new menu();
                men.Show();

            }
            else
            {
                MessageBox.Show("Please Enter correct password and username","error",MessageBoxButtons.OK,MessageBoxIcon.Error);
           }
        }
    }
}
