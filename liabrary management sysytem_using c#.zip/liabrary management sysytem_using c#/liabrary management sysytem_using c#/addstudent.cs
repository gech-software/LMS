﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace liabrary_management_sysytem_using_c_
{
    public partial class addstudent : Form
    {
        public addstudent()
        {
            InitializeComponent();
        }

        private void addstudent_Load(object sender, EventArgs e)
        {

        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("confirm?","Alert",MessageBoxButtons.OKCancel,MessageBoxIcon.Warning)==DialogResult.OK)
            {
                this.Close();

            }
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            if (txtstudentname.Text != ""&& txtstudentid.Text!=""&& txtdepartment.Text!="" && txtclassyear.Text!="" &&txtcontactinfo.Text!="")
            {
                string name = txtstudentname.Text;
                string id = txtstudentid.Text;
                string dept = txtdepartment.Text;
                string classyear = txtclassyear.Text;
                string contact = txtcontactinfo.Text;

                SqlConnection conn = new SqlConnection();

                conn.Open();
                SqlCommand comm = new SqlCommand();
                
                comm.CommandText = "insert into student(sname,sid,dept,classy,contact)value('" + name + "' , '" + id + "','" + dept + "','" + "','" + classyear + "' , '" + contact + "')";
                comm.ExecuteNonQuery();
                comm.Connection = conn;
              }
            else
            {
                MessageBox.Show("Fill all requirments ", "warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

        }
    }
}
