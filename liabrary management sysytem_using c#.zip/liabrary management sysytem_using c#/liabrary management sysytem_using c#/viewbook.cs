﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace liabrary_management_sysytem_using_c_
{
    public partial class viewbook : Form
    {
        public viewbook()
        {
            InitializeComponent();
        }

        private void viewbook_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.Open();
            string s = "SELECT * FROM book";
            SqlCommand comm = new SqlCommand(s, con);          
            SqlDataAdapter da = new SqlDataAdapter(comm);
            DataSet ds = new DataSet();
           da.Fill(ds);
            


        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null)
            {
              int bid = int.Parse(dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString());
                MessageBox.Show(dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString());
            }
            SqlConnection con = new SqlConnection();
            con.Open();
            string s = "SELECT * FROM book";
            SqlCommand comm = new SqlCommand(s, con);
            SqlDataAdapter da = new SqlDataAdapter(comm);
            DataSet ds = new DataSet();
            da.Fill(ds);


            /*
            txtbookname.Text = ds.Tables[0].Rows[0][1].ToString();
            txtauthorname.Text = ds.Tables[0].Rows[0][2].ToString();
            publicationdateTime.Text = ds.Tables[0].Rows[0][3].ToString();
            purchasedateTime.Text = ds.Tables[0].Rows[0][4].ToString();
            txtquality.Text = ds.Tables[0].Rows[0][5].ToString();
            txtquantity.Text = ds.Tables[0].Rows[0][6].ToString();*/



        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            
        }

        private void txtbookname2_TextChanged(object sender, EventArgs e)
        {
           if (txtbookname2.Text !="")
            {
                SqlConnection con = new SqlConnection();
                con.Open();
                string s = "SELECT * FROM book";
                SqlCommand comm = new SqlCommand(s, con);
                SqlDataAdapter da = new SqlDataAdapter(comm);
                DataSet ds = new DataSet();
                da.Fill(ds);

            
          }
            
        
        }

        private void btnsearch_Click(object sender, EventArgs e)
        {

        }
    }
}
