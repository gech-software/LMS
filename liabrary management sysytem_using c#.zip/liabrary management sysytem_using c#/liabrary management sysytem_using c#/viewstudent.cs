﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace liabrary_management_sysytem_using_c_
{
    public partial class viewstudent : Form
    {
        public viewstudent()
        {
            InitializeComponent();
        }

        private void viewstudent_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.Open();
            string s = "SELECT * FROM student";
            SqlCommand comm = new SqlCommand(s, con);
            SqlDataAdapter da = new SqlDataAdapter(comm);
            DataSet ds = new DataSet();
            da.Fill(ds);
        }
    }
}
