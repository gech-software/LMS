﻿namespace liabrary_management_sysytem_using_c_
{
    partial class viewbook
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(viewbook));
            this.bookname = new System.Windows.Forms.Label();
            this.txtbookname2 = new System.Windows.Forms.TextBox();
            this.btnsearch = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtquality = new System.Windows.Forms.TextBox();
            this.txtbookname = new System.Windows.Forms.TextBox();
            this.txtauthorname = new System.Windows.Forms.TextBox();
            this.btnok = new System.Windows.Forms.Button();
            this.btncancel = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.txtquantity = new System.Windows.Forms.TextBox();
            this.publicationdateTime = new System.Windows.Forms.DateTimePicker();
            this.purchasedateTime = new System.Windows.Forms.DateTimePicker();
            this.btnupdate = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // bookname
            // 
            this.bookname.AutoSize = true;
            this.bookname.BackColor = System.Drawing.Color.LightSalmon;
            this.bookname.Font = new System.Drawing.Font("Showcard Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bookname.Location = new System.Drawing.Point(39, 18);
            this.bookname.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.bookname.Name = "bookname";
            this.bookname.Size = new System.Drawing.Size(119, 23);
            this.bookname.TabIndex = 0;
            this.bookname.Text = "BOOK NAME";
            // 
            // txtbookname2
            // 
            this.txtbookname2.Location = new System.Drawing.Point(196, 17);
            this.txtbookname2.Margin = new System.Windows.Forms.Padding(4);
            this.txtbookname2.Name = "txtbookname2";
            this.txtbookname2.Size = new System.Drawing.Size(437, 24);
            this.txtbookname2.TabIndex = 1;
            this.txtbookname2.TextChanged += new System.EventHandler(this.txtbookname2_TextChanged);
            // 
            // btnsearch
            // 
            this.btnsearch.BackColor = System.Drawing.Color.Sienna;
            this.btnsearch.Font = new System.Drawing.Font("Showcard Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsearch.Location = new System.Drawing.Point(707, 18);
            this.btnsearch.Margin = new System.Windows.Forms.Padding(4);
            this.btnsearch.Name = "btnsearch";
            this.btnsearch.Size = new System.Drawing.Size(112, 30);
            this.btnsearch.TabIndex = 2;
            this.btnsearch.Text = "SEARCH";
            this.btnsearch.UseVisualStyleBackColor = false;
            this.btnsearch.Click += new System.EventHandler(this.btnsearch_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.LightSalmon;
            this.label1.Location = new System.Drawing.Point(40, 99);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(87, 17);
            this.label1.TabIndex = 3;
            this.label1.Text = "book  name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.LightSalmon;
            this.label2.Location = new System.Drawing.Point(3, 163);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(143, 17);
            this.label2.TabIndex = 4;
            this.label2.Text = "book author name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.LightSalmon;
            this.label3.Location = new System.Drawing.Point(3, 226);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(143, 17);
            this.label3.TabIndex = 5;
            this.label3.Text = "pupblication date";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.LightSalmon;
            this.label4.Location = new System.Drawing.Point(14, 291);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(113, 17);
            this.label4.TabIndex = 6;
            this.label4.Text = "purchase date";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.LightSalmon;
            this.label5.Location = new System.Drawing.Point(20, 352);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(107, 17);
            this.label5.TabIndex = 7;
            this.label5.Text = "book quality";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.LightSalmon;
            this.label6.Location = new System.Drawing.Point(9, 420);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(118, 17);
            this.label6.TabIndex = 8;
            this.label6.Text = "book quantity";
            // 
            // txtquality
            // 
            this.txtquality.Location = new System.Drawing.Point(175, 349);
            this.txtquality.Name = "txtquality";
            this.txtquality.Size = new System.Drawing.Size(300, 24);
            this.txtquality.TabIndex = 9;
            // 
            // txtbookname
            // 
            this.txtbookname.Location = new System.Drawing.Point(196, 92);
            this.txtbookname.Name = "txtbookname";
            this.txtbookname.Size = new System.Drawing.Size(300, 24);
            this.txtbookname.TabIndex = 11;
            // 
            // txtauthorname
            // 
            this.txtauthorname.Location = new System.Drawing.Point(196, 156);
            this.txtauthorname.Name = "txtauthorname";
            this.txtauthorname.Size = new System.Drawing.Size(300, 24);
            this.txtauthorname.TabIndex = 12;
            // 
            // btnok
            // 
            this.btnok.BackColor = System.Drawing.Color.Sienna;
            this.btnok.Location = new System.Drawing.Point(52, 476);
            this.btnok.Name = "btnok";
            this.btnok.Size = new System.Drawing.Size(75, 23);
            this.btnok.TabIndex = 15;
            this.btnok.Text = "OK";
            this.btnok.UseVisualStyleBackColor = false;
            // 
            // btncancel
            // 
            this.btncancel.BackColor = System.Drawing.Color.Sienna;
            this.btncancel.Location = new System.Drawing.Point(285, 476);
            this.btncancel.Name = "btncancel";
            this.btncancel.Size = new System.Drawing.Size(75, 23);
            this.btncancel.TabIndex = 16;
            this.btncancel.Text = "CANCEL";
            this.btncancel.UseVisualStyleBackColor = false;
            this.btncancel.Click += new System.EventHandler(this.btncancel_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(664, 58);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(331, 444);
            this.dataGridView1.TabIndex = 17;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // txtquantity
            // 
            this.txtquantity.Location = new System.Drawing.Point(175, 420);
            this.txtquantity.Name = "txtquantity";
            this.txtquantity.Size = new System.Drawing.Size(300, 24);
            this.txtquantity.TabIndex = 18;
            // 
            // publicationdateTime
            // 
            this.publicationdateTime.Location = new System.Drawing.Point(175, 226);
            this.publicationdateTime.Name = "publicationdateTime";
            this.publicationdateTime.Size = new System.Drawing.Size(300, 24);
            this.publicationdateTime.TabIndex = 19;
            // 
            // purchasedateTime
            // 
            this.purchasedateTime.Location = new System.Drawing.Point(149, 291);
            this.purchasedateTime.Name = "purchasedateTime";
            this.purchasedateTime.Size = new System.Drawing.Size(326, 24);
            this.purchasedateTime.TabIndex = 20;
            // 
            // btnupdate
            // 
            this.btnupdate.BackColor = System.Drawing.Color.Sienna;
            this.btnupdate.Location = new System.Drawing.Point(175, 479);
            this.btnupdate.Name = "btnupdate";
            this.btnupdate.Size = new System.Drawing.Size(75, 23);
            this.btnupdate.TabIndex = 21;
            this.btnupdate.Text = "UPDATE";
            this.btnupdate.UseVisualStyleBackColor = false;
            // 
            // viewbook
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(997, 514);
            this.Controls.Add(this.btnupdate);
            this.Controls.Add(this.purchasedateTime);
            this.Controls.Add(this.publicationdateTime);
            this.Controls.Add(this.txtquantity);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.btncancel);
            this.Controls.Add(this.btnok);
            this.Controls.Add(this.txtauthorname);
            this.Controls.Add(this.txtbookname);
            this.Controls.Add(this.txtquality);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnsearch);
            this.Controls.Add(this.txtbookname2);
            this.Controls.Add(this.bookname);
            this.Font = new System.Drawing.Font("Showcard Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "viewbook";
            this.Text = "viewbook";
            this.Load += new System.EventHandler(this.viewbook_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label bookname;
        private System.Windows.Forms.TextBox txtbookname2;
        private System.Windows.Forms.Button btnsearch;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtquality;
        private System.Windows.Forms.TextBox txtbookname;
        private System.Windows.Forms.TextBox txtauthorname;
        private System.Windows.Forms.Button btnok;
        private System.Windows.Forms.Button btncancel;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox txtquantity;
        private System.Windows.Forms.DateTimePicker publicationdateTime;
        private System.Windows.Forms.DateTimePicker purchasedateTime;
        private System.Windows.Forms.Button btnupdate;
    }
}