﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace liabrary_management_sysytem_using_c_
{
    public partial class addbook : Form
    {
        public addbook()
        {
            InitializeComponent();
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }
        //when you enter save button the information will be automaticaly save to the database
        
        private void button1_Click(object sender, EventArgs e)
        {
            if (txtbookname.Text!=" "&& txtauthorname.Text!="" && txtbookquantity.Text!=" "&& publicationdatatime.Text!=""&& purchasedateTime.Text!=""&& purchasedateTime.Text!="") {
                string bookname = txtbookname.Text;
                string authorname = txtauthorname.Text;
                string publication = publicationdatatime.Text;
                string purchase = purchasedateTime.Text;
                string quality = txtbookquality.Text;
                string quantity = txtbookquantity.Text;

                SqlConnection conn = new SqlConnection();
                conn.Open();
                SqlCommand com = new SqlCommand();
              com.CommandText="insert into book(bname,bauthor,bpubl,bpdate,bqual,bquan)value('"+bookname+ "' , '"+authorname+"','"+publication+"','"+"','"+quality+"' , '"+quantity+"')";
                com.ExecuteNonQuery();

                conn.Close(); }
            else
            {
                MessageBox.Show("Fill all requirments ","warning",MessageBoxButtons.OK,MessageBoxIcon.Warning);
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("confirm?", "Alert", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning) == DialogResult.OK)
            {
                this.Close();

            }
        }
    }
}
